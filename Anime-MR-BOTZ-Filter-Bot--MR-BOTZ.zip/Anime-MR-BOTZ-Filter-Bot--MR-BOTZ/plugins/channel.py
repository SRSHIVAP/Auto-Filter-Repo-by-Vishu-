import re
import logging
import asyncio
import pytz
from datetime import datetime
from collections import defaultdict
from plugins.Deendayal.Imdbposter import get_movie_detailsx, fetch_image, get_movie_details
from database.users_chats_db import db
from pyrogram import Client, filters, enums
from info import MOVIE_GROUP, CHANNELS, MOVIE_UPDATE_CHANNEL, LINK_PREVIEW, ABOVE_PREVIEW, BAD_WORDS, LANDSCAPE_POSTER, TMDB_POSTER, IMDB_POSTER
from Script import script
from database.ia_filterdb import save_file
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utils import temp
from pymongo.errors import PyMongoError, DuplicateKeyError
from pyrogram.errors import MessageIdInvalid, MessageNotModified, FloodWait
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# Precomputed sets for faster lookups
IGNORE_WORDS = {
    "rarbg", "dub", "sub", "sample", "mkv", "aac", "combined",
    "action", "adventure", "animation", "biography", "comedy", "crime",
    "documentary", "drama", "fantasy", "film-noir", "history",
    "horror", "music", "musical", "mystery", "romance", "sci-fi", "sport",
    "thriller", "war", "western", "hdcam", "hdtc", "camrip", "ts", "tc",
    "telesync", "dvdscr", "dvdrip", "predvd", "webrip", "web-dl", "tvrip",
    "hdtv", "web dl", "webdl", "bluray", "brrip", "bdrip", "360p", "480p",
    "720p", "1080p", "2160p", "4k", "1440p", "540p", "240p", "140p", "hevc",
    "hdrip", "hin", "hindi", "tam", "tamil", "kan", "kannada", "tel", "telugu",
    "mal", "malayalam", "eng", "english", "pun", "punjabi", "ben", "bengali",
    "mar", "marathi", "guj", "gujarati", "urd", "urdu", "kor", "korean", "jpn",
    "japanese", "nf", "netflix", "sonyliv", "sony", "sliv", "amzn", "prime",
    "primevideo", "hotstar", "zee5", "jio", "jhs", "aha", "hbo", "paramount",
    "apple", "hoichoi", "sunnxt", "viki"
}|BAD_WORDS

# Constants
CAPTION_LANGUAGES = {
    "hindi": "Hindi", "hindi": "Hindi",
    "tamil": "Tamil", "tamil": "Tamil",
    "kannada": "Kannada", "kannada": "Kannada",
    "telugu": "Telugu", "telugu": "Telugu",
    "malayalam": "Malayalam", "malayalam": "Malayalam",
    "english": "English", "english": "English",
    "punjabi": "Punjabi", "punjabi": "Punjabi",
    "bengali": "Bengali", "bengali": "Bengali",
    "marathi": "Marathi", "marathi": "Marathi",
    "gujarati": "Gujarati", "gujarati": "Gujarati",
    "bangla": "Bangla",
    "urdu": "Urdu", "urdu": "Urdu",
    "korean": "Korean", "korean": "Korean",
    "Japanese": "Japanese", "japanese": "Japanese",
    "multi audio": "Multi Audio",
    "dual audio": "Dual Audio",
}

OTT_PLATFORMS = {
    "nf": "Netflix", "netflix": "Netflix",
    "sonyliv": "SonyLiv", "sony": "SonyLiv", "sliv": "SonyLiv",
    "amzn": "Amazon Prime Video", "prime": "Amazon Prime Video", "primevideo": "Amazon Prime Video",
    "hotstar": "Disney+ Hotstar", "ZEE5": "ZEE5",
    "jio": "JioHotstar", "jhs": "JioHotstar", "SM": "ShemarooMe",
    "aha": "Aha", "hbo": "HBO Max", "paramount": "Paramount+", "CR": "Crunchyroll",
    "ATV": "Apple TV+", "hoichoi": "Hoichoi", "snxt": "Sun NXT", "viki": "Viki"
}

STANDARD_GENRES = {
    'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Documentary',
    'Drama', 'Family', 'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music',
    'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller', 'War', 'Western'
}

# Precompiled regex patterns
CLEAN_PATTERN = re.compile(r'@[^ \n\r\t\.,:;!?()\[\]{}<>\\/"\'=_%]+|\bwww\.[^\s\]\)]+|\([\@^]+\)|\[[\@^]+\]')
NORMALIZE_PATTERN = re.compile(r"[._]+|[()\[\]{}:;'–!,.?_]")
QUALITY_PATTERN = re.compile(
    r"\b(?:HDCam|HDTC|CamRip|TS|TC|TeleSync|DVDScr|DVDRip|PreDVD|"
    r"WEBRip|WEB-DL|TVRip|HDTV|BluRay|BRRip|BDRip|"
    r"360p|480p|720p|1080p|4K-2160p|2160p|4K|1440p|540p|240p|140p|HDRip)\b",
    re.IGNORECASE
)
YEAR_PATTERN = re.compile(r"(?<![A-Za-z0-9])(?:19|20)\d{2}(?![A-Za-z0-9])")
RANGE_REGEX = re.compile(r'\bS(\d{1,2})[^\w\n\r]*E(?:p(?:isode)?)?0*(\d{1,2})\s*(?:to|-)\s*(?:E(?:p(?:isode)?)?)?0*(\d{1,2})',re.IGNORECASE)
SINGLE_REGEX = re.compile(r'\bS(\d{1,2})[^\w\n\r]*E(?:p(?:isode)?)?0*(\d{1,3})', re.IGNORECASE)
NAMED_REGEX = re.compile(r'Season\s*0*(\d{1,2})[\s\-,:]*Ep(?:isode)?\s*0*(\d{1,3})', re.IGNORECASE)
EP_ONLY_RANGE = re.compile(r'\b(?:EP|Episode)0*(\d{1,3})\s*-\s*0*(\d{1,3})\b',re.IGNORECASE)


MEDIA_FILTER = filters.document | filters.video | filters.audio
locks = defaultdict(asyncio.Lock)
pending_updates = {}


def clean_mentions_links(text: str) -> str:
    return CLEAN_PATTERN.sub("", text or "").strip()

def normalize(s: str) -> str:
    s = NORMALIZE_PATTERN.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()

def remove_ignored_words(text: str) -> str:
    IGNORE_WORDS_LOWER = {w.lower() for w in IGNORE_WORDS}
    return " ".join(word for word in text.split() if word.lower() not in IGNORE_WORDS_LOWER)

def get_qualities(text: str) -> str:
    qualities = QUALITY_PATTERN.findall(text)
    return ", ".join(qualities) if qualities else "N/A"

QUALITY_ORDER = [
    "240p", "360p", "480p", "540p", "720p", "1080p", "1440p", "4K-2160p"
]
QUALITY_EMOJIS = {
    "240p": "🔴",
    "360p": "🟠",
    "480p": "🟢",
    "540p": "🟡",
    "720p": "🔵",
    "1080p": "🟣",
    "1440p": "🟤",
    "4K-2160p": "⚪",
}

def get_quality_buttons(movie_doc, group_id):
    extracted_qualities = set()
    for file in movie_doc.get("files", []):
        if file.get("quality", "N/A") != "N/A":
            for q in file["quality"].split(","):
                q = q.strip()
                if q:
                    extracted_qualities.add(q)

    matched_qualities = []
    for q in extracted_qualities:
        q_upper = q.upper()
        for valid_q in QUALITY_ORDER:
            if valid_q.upper() == q_upper:
                matched_qualities.append(valid_q)
                break

    if not matched_qualities:
        return []

    matched_qualities.sort(key=lambda x: QUALITY_ORDER.index(x))

    buttons = []
    buttons.append([InlineKeyboardButton("🎬 Available Quality", callback_data="ignore")])

    bot_username = temp.U_NAME
    base_name = group_id.replace(" ", "-")

    row = []
    for q in matched_qualities:
        emoji = QUALITY_EMOJIS.get(q, "🔵")
        text = f"{emoji} {q}"
        url = f"https://t.me/{bot_username}?start=getfile-{base_name}-{q}"
        row.append(InlineKeyboardButton(text, url=url))
        if len(row) == 3:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    return buttons

def get_episode_buttons(movie_doc, group_id):
    extracted_episodes = set()
    for file in movie_doc.get("files", []):
        filename = file.get("filename", "")
        # First try to parse from the filename to support all common formats correctly
        _, ep_val = extract_season_episode(filename)
        # Fallback to the saved episode field just in case
        if not ep_val:
            ep_val = file.get("episode")

        if ep_val:
            ep_val = str(ep_val).strip()
            if "-" in ep_val:
                parts = ep_val.split("-")
                if len(parts) == 2:
                    try:
                        start = int(parts[0].strip())
                        end = int(parts[1].strip())
                        if start <= end and (end - start) <= 100:
                            for i in range(start, end + 1):
                                extracted_episodes.add(i)
                    except ValueError:
                        pass
            else:
                try:
                    num = int(ep_val.strip())
                    extracted_episodes.add(num)
                except ValueError:
                    pass

    if not extracted_episodes:
        return []

    sorted_episodes = sorted(list(extracted_episodes))

    if len(sorted_episodes) > 80:
        sorted_episodes = sorted_episodes[:80]

    buttons = []
    buttons.append([InlineKeyboardButton("🎞 Available Episodes", callback_data="ignore")])

    bot_username = temp.U_NAME
    base_name = group_id.replace(" ", "-")

    row = []
    for ep in sorted_episodes:
        ep_str = f"E{ep:02d}"
        url = f"https://t.me/{bot_username}?start=getfile-{base_name}-{ep_str}"
        row.append(InlineKeyboardButton(ep_str, url=url))
        if len(row) == 4:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    return buttons

def extract_ott_platform(text: str) -> str:
    text = text.lower()
    platforms = {plat for key, plat in OTT_PLATFORMS.items() if key in text}
    return " | ".join(platforms) if platforms else "N/A"

def extract_season_episode(filename: str) -> Tuple[Optional[int], Optional[str]]:
    if m := EP_ONLY_RANGE.search(filename):
        return 1, f"{int(m.group(1))}-{int(m.group(2))}"
    for pattern in (RANGE_REGEX, SINGLE_REGEX, NAMED_REGEX):
        if m := pattern.search(filename):
            season = int(m.group(1))
            if pattern == RANGE_REGEX:
                ep = f"{m.group(2)}-{m.group(3)}"
            else:
                ep = m.group(2)
            return season, ep
    return None, None

def schedule_update(bot, group_id, delay=5):
    if handle := pending_updates.get(group_id):
        if not handle.cancelled():
            handle.cancel()

    loop = asyncio.get_event_loop()
    pending_updates[group_id] = loop.call_later(
        delay,
        lambda: asyncio.create_task(update_movie_message(bot, group_id))
    )

def extract_media_info(filename: str, caption: str):
    filename = normalize(clean_mentions_links(filename).title())
    caption_clean = normalize(clean_mentions_links(caption)).lower() if caption else ""
    unified = f"{caption_clean} {filename.lower()}".strip()

    season = episode = year = None
    tag = "#MOVIE"
    processed_raw = base_raw = filename
    quality = get_qualities(caption_clean) or get_qualities(filename.lower()) or "N/A"
    ott_platform = extract_ott_platform(f"{filename} {caption_clean}")

    lang_keys = {k for k in CAPTION_LANGUAGES if k in caption_clean or k in filename.lower()}
    language = ", ".join(sorted({CAPTION_LANGUAGES[k] for k in lang_keys})) if lang_keys else "N/A"

    season, episode = extract_season_episode(filename)
    if season is not None:
        tag = "#SERIES"
        if m := (RANGE_REGEX.search(filename) or SINGLE_REGEX.search(filename) or NAMED_REGEX.search(filename) or EP_ONLY_RANGE.search(filename)):
            match_str = m.group(0)
            start_idx = filename.lower().find(match_str.lower())
            end_idx = start_idx + len(match_str)
            processed_raw = filename[:end_idx]
            base_raw = filename[:start_idx]
            if year_match := YEAR_PATTERN.search(filename.lower()[end_idx:]):
                y = year_match.group(0)
                yi = filename.lower().find(y, end_idx)
                if yi != -1:
                    processed_raw = filename[:yi+4]
                    base_raw += f" {y}"
    else:
        if year_match := YEAR_PATTERN.search(unified):
            year = year_match.group(0)
            year_idx = filename.lower().find(year.lower())
            if year_idx != -1:
                processed_raw = filename[:year_idx + 4]
                base_raw = processed_raw
        else:
            if qual_match := QUALITY_PATTERN.search(unified):
                qual_str = qual_match.group(0)
                qual_idx = filename.lower().find(qual_str.lower())
                if qual_idx != -1:
                    processed_raw = filename[:qual_idx]
                    base_raw = processed_raw

    base_name = normalize(remove_ignored_words(normalize(base_raw)))
    if year and year not in base_name:
        base_name += f" {year}"

    if base_name.endswith(")"):
        base_name = re.sub(r"\s+\(\d{4}\)$", "", base_name)
        if year:
            base_name += f" ({year})"

    return {
        "processed": normalize(processed_raw),
        "base_name": base_name,
        "tag": tag,
        "season": season,
        "episode": episode,
        "year": year,
        "quality": quality,
        "ott_platform": ott_platform,
        "language": language
    }

@Client.on_message(filters.chat(CHANNELS) & MEDIA_FILTER)
async def media_handler(bot, message):
    media = next(
        (getattr(message, ft) for ft in ("document", "video", "audio")
         if getattr(message, ft, None)),
        None
    )
    if not media:
        return

    media.file_type = next(ft for ft in ("document", "video", "audio") if hasattr(message, ft))
    media.caption = message.caption or ""
    success, info = await save_file(bot, media)
    if not success:
        return

    try:
        if await db.movie_update_status(bot.me.id):
            await process_and_send_update(bot, media.file_name, media.caption)
    except Exception:
        logger.exception("Error processing media")

async def process_and_send_update(bot, filename, caption):
    try:
        media_info = extract_media_info(filename, caption)
        base_name = media_info["base_name"]
        processed = media_info["processed"]

        group_id = base_name
        if media_info.get("season"):
            season_num = media_info["season"]
            group_id = f"{base_name} S{int(season_num):02d}"

        lock = locks[group_id]
        async with lock:
            await _process_with_lock(bot, filename, caption, media_info, base_name, processed, group_id)
    except PyMongoError as e:
        logger.error("Database error: %s", e)
    except Exception as e:
        logger.exception("Processing failed: %s", e)

async def _process_with_lock(bot, filename, caption, media_info, base_name, processed, group_id):
    if not hasattr(db, 'movie_updates'):
        db.movie_updates = db.db.movie_updates

    movie_doc = await db.movie_updates.find_one({"_id": group_id})
    global error_tmdb
    error_tmdb=False
    file_data = {
        "filename": filename,
        "processed": processed,
        "quality": media_info["quality"],
        "language": media_info["language"],
        "ott_platform": media_info["ott_platform"],
        "timestamp": datetime.now(),
        "tag": media_info["tag"],
        "season": media_info["season"],
        "episode": media_info["episode"]
    }

    if not movie_doc:
        details = {}
        error_tmdb = False
        imdb_details = await get_movie_details(base_name) or {}
        tmdb_details = {}

        # Always fetch TMDB details to get backdrops and fallback info
        tmdb_details = await get_movie_detailsx(base_name)
        if tmdb_details.get("error") or not tmdb_details:
            error_tmdb = True
            # Smart Retry: Use IMDb corrected title to try TMDB again
            if imdb_details and imdb_details.get("title"):
                corrected_title = imdb_details["title"]
                if corrected_title.lower() != base_name.lower():
                    logger.info(f"Retrying TMDB with corrected title: {corrected_title}")
                    tmdb_retry = await get_movie_detailsx(corrected_title)
                    if tmdb_retry and not tmdb_retry.get("error"):
                        tmdb_details = tmdb_retry
                        error_tmdb = False

        # User requirement:
        # First preference for image: TMDB backdrop only. If no TMDB backdrop, then IMDB poster.
        # First preference for info: IMDB details (rating, genres, runtime). If no IMDB info, then TMDB.

        poster_url = None
        # Try to get backdrop from TMDB
        poster_url = tmdb_details.get("backdrop_url")
        if not poster_url:
            # If no backdrop, use IMDb poster
            poster_url = imdb_details.get("poster")

        # Info preference: IMDB first, then TMDB
        # We track where the info comes from separately from the image
        info_source_is_tmdb = False

        # Check if we have meaningful IMDB info
        imdb_has_info = bool(imdb_details and (imdb_details.get("rating") or imdb_details.get("genres") or imdb_details.get("runtime")))
        tmdb_has_info = bool(tmdb_details and not tmdb_details.get("error"))

        if imdb_has_info:
            info_source_is_tmdb = False
        elif tmdb_has_info:
            info_source_is_tmdb = True
        else:
            # If both fail or have no meaningful info, default to IMDB for consistency
            info_source_is_tmdb = False

        raw_genres = imdb_details.get("genres", "N/A")
        if raw_genres in ("N/A", "", None, []) and tmdb_has_info and tmdb_details.get("genres"):
            raw_genres = tmdb_details.get("genres")

        rating = imdb_details.get("rating", "N/A")
        if rating in ("N/A", "", None) and tmdb_has_info and tmdb_details.get("rating"):
            rating = str(tmdb_details.get("rating"))

        runtime = imdb_details.get("runtime")
        if not runtime and tmdb_has_info and tmdb_details.get("runtime"):
            runtime = str(tmdb_details.get("runtime"))

        # For URL and rating source, we use IMDB if available
        # But if the entire info came from TMDB, then use TMDB url.
        url = ""
        if info_source_is_tmdb:
             url = tmdb_details.get("tmdb_url", "") or imdb_details.get("url", "")
        else:
             url = imdb_details.get("url", "") or tmdb_details.get("tmdb_url", "")

        rating_source = "tmdb" if info_source_is_tmdb else "imdb"

        if isinstance(raw_genres, str):
            genre_list = [g.strip() for g in raw_genres.split(",")]
            genres = ", ".join(g for g in genre_list if g in STANDARD_GENRES) or "N/A"
        else:
            genres = ", ".join(g for g in raw_genres if g in STANDARD_GENRES) or "N/A"

        movie_doc = {
            "_id": group_id,
            "files": [file_data],
            "poster_url": poster_url,
            "genres": genres,
            "rating": rating,
            "rating_source": rating_source,
            "runtime": runtime,
            "imdb_url": url, # Kept for backward DB compatibility, stores the actual source URL
            "url": url,
            "source": "tmdb" if info_source_is_tmdb else "imdb",
            "year": media_info["year"] or imdb_details.get("year"),
            "tag": media_info["tag"],
            "ott_platform": media_info["ott_platform"],
            "message_id": None,
            "is_photo": False
        }
        try:
            await db.movie_updates.insert_one(movie_doc)
            await send_movie_update(bot, group_id)
            movie_doc = await db.movie_updates.find_one({"_id": group_id})
        except DuplicateKeyError:
            movie_doc = await db.movie_updates.find_one({"_id": group_id})
            if movie_doc:
                if not any(f["filename"] == filename for f in movie_doc["files"]):
                    await db.movie_updates.update_one(
                        {"_id": group_id},
                        {"$push": {"files": file_data}}
                    )
                    movie_doc["files"].append(file_data)
                schedule_update(bot, group_id)
    else:
        if not any(f["filename"] == filename for f in movie_doc["files"]):
            await db.movie_updates.update_one(
                {"_id": group_id},
                {"$push": {"files": file_data}}
            )
            movie_doc["files"].append(file_data)
        schedule_update(bot, group_id)

async def send_movie_update(bot, group_id):
    max_retries = 3
    base_delay = 5
    for attempt in range(max_retries):
        try:
            movie_doc = await db.movie_updates.find_one({"_id": group_id})
            if not movie_doc:
                return None

            text = generate_movie_message(movie_doc, group_id)

            is_series = any(f.get("season") for f in movie_doc.get("files", []))
            if is_series:
                button_list = []
            else:
                button_list = get_quality_buttons(movie_doc, group_id)

            button_list.append([
                InlineKeyboardButton(
                    '♻️ 𝗠𝗼𝘃𝗶𝗲 𝗦𝗲𝗮𝗿𝗰𝗵 𝗚𝗿𝗼𝘂𝗽 ♻️',
                    url=MOVIE_GROUP
                )
            ])
            buttons = InlineKeyboardMarkup(button_list)

            if movie_doc.get("poster_url") and not LINK_PREVIEW:
                resized_poster = await fetch_image(movie_doc["poster_url"], size=(2560, 1440) if LANDSCAPE_POSTER else (853, 1280))
                msg = await bot.send_photo(has_spoiler=True,
                    chat_id=MOVIE_UPDATE_CHANNEL,
                    photo=resized_poster,
                    caption=text,
                    reply_markup=buttons,
                    parse_mode=enums.ParseMode.HTML
                )
                is_photo = True
            else:
                send_params = {
                    "chat_id": MOVIE_UPDATE_CHANNEL,
                    "text": text,
                    "reply_markup": buttons,
                    "parse_mode": enums.ParseMode.HTML,
                    "disable_web_page_preview": True
                }
                if movie_doc.get("poster_url") and LINK_PREVIEW:
                    send_params["invert_media"] = ABOVE_PREVIEW
                msg = await bot.send_message(**send_params)
                is_photo = False

            await db.movie_updates.update_one(
                {"_id": group_id},
                {"$set": {"message_id": msg.id, "is_photo": is_photo}}
            )
            return msg
        except FloodWait as e:
            wait_time = e.value + 2
            await asyncio.sleep(wait_time)
        except Exception as e:
            logger.error(f"Failed to send movie update: {e}")
            break
    return None

async def update_movie_message(bot, group_id):
    try:
        movie_doc = await db.movie_updates.find_one({"_id": group_id})
        if not movie_doc:
            return

        text = generate_movie_message(movie_doc, group_id)

        is_series = any(f.get("season") for f in movie_doc.get("files", []))
        if is_series:
            button_list = []
        else:
            button_list = get_quality_buttons(movie_doc, group_id)

        button_list.append([
            InlineKeyboardButton(
                '♻️ 𝗠𝗼𝘃𝗶𝗲 𝗦𝗲𝗮𝗿𝗰𝗵 𝗚𝗿𝗼𝘂𝗽 ♻️',
                url=MOVIE_GROUP
            )
        ])
        buttons = InlineKeyboardMarkup(button_list)

        message_id = movie_doc.get("message_id")
        is_photo = movie_doc.get("is_photo", False)

        if not message_id:
            await send_movie_update(bot, group_id)
            return

        try:
            await bot.delete_messages(
                chat_id=MOVIE_UPDATE_CHANNEL,
                message_ids=message_id
            )
        except Exception:
            pass
        await send_movie_update(bot, group_id)
    except Exception as e:
        logger.error(f"Failed to update movie message: {e}")

def generate_movie_message(movie_doc, group_id):
    all_qualities = set()
    all_languages = set()
    all_ott_platforms = set()
    all_tags = set()
    episodes_by_season = defaultdict(set)

    for file in movie_doc["files"]:
        if file["quality"] != "N/A":
            all_qualities.update(q.strip() for q in file["quality"].split(",") if q.strip())
        if file["language"] != "N/A":
            all_languages.update(l.strip() for l in file["language"].split(",") if l.strip())
        if file["ott_platform"] != "N/A":
            platforms = [p.strip() for p in file["ott_platform"].split("|") if p.strip()]
            all_ott_platforms.update(platforms)
        if file["tag"]:
            all_tags.add(file["tag"])
        if file.get("season") and file.get("episode"):
            season = file["season"]
            episode = file["episode"]
            episodes_by_season[season].add(episode)

    primary_tag = "#SERIES" if "#SERIES" in all_tags else "#MOVIE"
    epi_block = ""
    if episodes_by_season:
        episode_lines = []
        for season, episodes in sorted(episodes_by_season.items(), key=lambda x: int(x[0])):
            singles = []
            ranges = []

            for ep in episodes:
                if "-" in ep:
                    ranges.append(ep)
                else:
                    try:
                        singles.append(int(ep))
                    except ValueError:
                        ranges.append(ep)

            singles.sort()
            collapsed = []
            start = end = None
            for num in singles:
                if start is None:
                    start = end = num
                elif num == end + 1:
                    end = num
                else:
                    collapsed.append(str(start) if start == end else f"{start}-{end}")
                    start = end = num
            if start is not None:
                collapsed.append(str(start) if start == end else f"{start}-{end}")

            all_ep_parts = collapsed + sorted(ranges, key=lambda s: int(s.split("-")[0]))
            episode_lines.append(f"S0{int(season)}: E ⪼ {'- '.join(all_ep_parts)}")

        epi_str = " | ".join(episode_lines)
        if epi_str:
            epi_block = f"🎬 ᴇᴘɪsᴏᴅᴇs : <b>{epi_str}</b>"

    genres = movie_doc.get("genres", "N/A")
    genres_block = f"\n<b>🎭 ɢᴇɴʀᴇs : {genres}</b>" if genres and genres != "N/A" else ""

    rating = movie_doc.get("rating", "N/A")
    # Determine rating source for label
    rating_source = movie_doc.get("rating_source")
    if not rating_source:
        # Fallback for old documents that didn't save rating_source
        url_fallback = movie_doc.get("url", "") or movie_doc.get("imdb_url", "")
        rating_source = "tmdb" if "themoviedb.org" in url_fallback else "imdb"

    rating_label = "ʀᴀᴛɪɴɢ" if rating_source == "tmdb" else "ʀᴀᴛɪɴɢ"
    rating_block = f"<b>🎞 {rating_label}  : {rating}</b>" if rating and rating != "N/A" else ""

    # Determine info link label
    url = movie_doc.get("url") or movie_doc.get("imdb_url", "")
    source = movie_doc.get("source")
    if not source:
        source = "tmdb" if "themoviedb.org" in url else "imdb"
    source_info = "ᴛᴍᴅʙ ɪɴғᴏ" if source == "tmdb" else "ɪᴍᴅʙ ɪɴғᴏ"

    # Format qualities
    QUALITY_MAP = {
        "web-dl": "WEB-DL", "webrip": "WEBRip", "hdcam": "HDCam", "hdtc": "HDTC",
        "camrip": "CamRip", "ts": "TS", "tc": "TC", "telesync": "TeleSync",
        "dvdscr": "DVDScr", "dvdrip": "DVDRip", "predvd": "PreDVD", "tvrip": "TVRip",
        "hdtv": "HDTV", "bluray": "BluRay", "brrip": "BRRip", "bdrip": "BDRip",
        "hdrip": "HDRip"
    }
    formatted_qualities = set()
    for q in all_qualities:
        q_lower = q.lower()
        if q_lower == "hevc":
            continue
        formatted_qualities.add(QUALITY_MAP.get(q_lower, q))

    quality_str = ", ".join(sorted(formatted_qualities)) if formatted_qualities else "N/A"
    language_str = ", ".join(sorted(all_languages)) if all_languages else "N/A"
    ott_str = ", ".join(sorted(all_ott_platforms)) if all_ott_platforms else "N/A"
    ott_line = f"🌐 ᴏᴛᴛ    : <b>{ott_str}</b>\n" if ott_str != "N/A" and ott_str else ""

    duration_str = ""
    raw_runtime = movie_doc.get("runtime")
    if raw_runtime:
        if isinstance(raw_runtime, list):
            raw_runtime = raw_runtime[0]

        raw_str = str(raw_runtime).lower()
        total_mins = 0

        match = re.search(r'(?:(\d+)\s*h\b\s*)?(?:(\d+)\s*m(?:in)?\b)?', raw_str)
        if match and (match.group(1) or match.group(2)):
            h = int(match.group(1)) if match.group(1) else 0
            m = int(match.group(2)) if match.group(2) else 0
            total_mins = h * 60 + m

        if not total_mins:
            digits = ''.join(filter(str.isdigit, raw_str))
            if digits:
                total_mins = int(digits)

        if total_mins:
            if total_mins > 59:
                hours = total_mins // 60
                minutes = total_mins % 60
                if minutes > 0:
                    formatted = f"{hours}h {minutes}m"
                else:
                    formatted = f"{hours}h"
            else:
                formatted = f"{total_mins} min"

            if primary_tag == "#SERIES":
                duration_str = f"\n<b>⏱ ᴅᴜʀᴀᴛɪᴏɴ : </b><b>{formatted}/ep (Avg)</b>"
            else:
                duration_str = f"\n<b>⏱ ᴅᴜʀᴀᴛɪᴏɴ : </b><b>{formatted}</b>"

    ist = pytz.timezone('Asia/Kolkata')
    now = datetime.now(ist)
    date_str = now.strftime("%d %b %Y")
    time_str = now.strftime("%I:%M:%S %p")

    return script.MOVIE_UPDATE_NOTIFY_TXT.format(
        poster_url=movie_doc.get("poster_url", ""),
        url=url,
        source_info=source_info,
        filename=group_id,
        tag=primary_tag,
        genres_block=genres_block,
        ott_line=ott_line,
        quality=quality_str,
        language=language_str,
        episodes=epi_block,
        rating_block=rating_block,
        duration=duration_str,
        search_link=temp.B_LINK,
        date=date_str,
        time=time_str
    )
